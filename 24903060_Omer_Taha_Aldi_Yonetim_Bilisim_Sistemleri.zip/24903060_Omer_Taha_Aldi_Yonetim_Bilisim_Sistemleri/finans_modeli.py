"""
finans_modeli.py
================
Kişisel Finans Takip Sistemi - Veri Modelleri

Bu modül, gelir ve gider işlemlerini temsil eden sınıfları içerir.
Her işlem (gelir/gider) bir nesne olarak saklanır ve yönetilir.

Sınıflar:
    - Islem: Temel işlem sınıfı (gelir/gider)
    - Gelir: Gelir işlemi (Islem'den türetilmiş)
    - Gider: Gider işlemi (Islem'den türetilmiş)

Öğrenci: Ömer Taha Aldı
Numara: 24903060
Bölüm: Yönetim Bilişim Sistemleri
Ders: BGY210 - Python Programlama-II
"""

from datetime import datetime


class Islem:
    """
    Temel İşlem Sınıfı
    
    Tüm finansal işlemlerin (gelir/gider) temel özelliklerini tanımlar.
    
    Özellikler:
        id (int): Benzersiz işlem kimliği
        tutar (float): İşlem tutarı (pozitif)
        tarih (str): İşlem tarihi (YYYY-MM-DD formatında)
        kategori (str): İşlem kategorisi
        aciklama (str): İşlem açıklaması
    """
    
    def __init__(self, id, tutar, tarih, kategori, aciklama=""):
        """
        İşlem nesnesini başlatır.
        
        Args:
            id (int): Benzersiz işlem kimliği
            tutar (float): İşlem tutarı
            tarih (str): İşlem tarihi (YYYY-MM-DD)
            kategori (str): İşlem kategorisi
            aciklama (str): İşlem açıklaması (opsiyonel)
        """
        self.id = id
        self.tutar = float(tutar)
        self.tarih = tarih
        self.kategori = kategori
        self.aciklama = aciklama
    
    def __str__(self):
        """İşlemi okunabilir formatta döndürür."""
        return (f"ID: {self.id} | Tutar: {self.tutar:.2f} TL | "
                f"Tarih: {self.tarih} | Kategori: {self.kategori} | "
                f"Açıklama: {self.aciklama}")
    
    def __repr__(self):
        """İşlemin Python temsilini döndürür."""
        return f"Islem(id={self.id}, tutar={self.tutar}, tarih='{self.tarih}')"
    
    def to_dict(self):
        """
        İşlemi sözlük formatına dönüştürür (CSV kayıt için).
        
        Returns:
            dict: İşlem bilgilerini içeren sözlük
        """
        return {
            'id': self.id,
            'tutar': self.tutar,
            'tarih': self.tarih,
            'kategori': self.kategori,
            'aciklama': self.aciklama
        }


class Gelir(Islem):
    """
    Gelir İşlemi Sınıfı
    
    Gelir işlemlerini temsil eder. Islem sınıfından türetilmiştir.
    Gelir kategorileri: Maaş, Bonus, Yatırım, Diğer
    
    Özellikler:
        tip (str): Her zaman "Gelir" olarak ayarlanır
    """
    
    def __init__(self, id, tutar, tarih, kategori, aciklama=""):
        """
        Gelir nesnesini başlatır.
        
        Args:
            id (int): Benzersiz işlem kimliği
            tutar (float): Gelir tutarı
            tarih (str): Gelir tarihi (YYYY-MM-DD)
            kategori (str): Gelir kategorisi
            aciklama (str): Gelir açıklaması (opsiyonel)
        """
        super().__init__(id, tutar, tarih, kategori, aciklama)
        self.tip = "Gelir"
    
    def __str__(self):
        """Geliri okunabilir formatta döndürür."""
        return f"[GELİR] {super().__str__()}"
    
    def __repr__(self):
        """Gelirin Python temsilini döndürür."""
        return f"Gelir(id={self.id}, tutar={self.tutar}, tarih='{self.tarih}')"


class Gider(Islem):
    """
    Gider İşlemi Sınıfı
    
    Gider işlemlerini temsil eder. Islem sınıfından türetilmiştir.
    Gider kategorileri: Yiyecek, Ulaşım, Eğlence, Sağlık, Diğer
    
    Özellikler:
        tip (str): Her zaman "Gider" olarak ayarlanır
    """
    
    def __init__(self, id, tutar, tarih, kategori, aciklama=""):
        """
        Gider nesnesini başlatır.
        
        Args:
            id (int): Benzersiz işlem kimliği
            tutar (float): Gider tutarı
            tarih (str): Gider tarihi (YYYY-MM-DD)
            kategori (str): Gider kategorisi
            aciklama (str): Gider açıklaması (opsiyonel)
        """
        super().__init__(id, tutar, tarih, kategori, aciklama)
        self.tip = "Gider"
    
    def __str__(self):
        """Gideri okunabilir formatta döndürür."""
        return f"[GİDER] {super().__str__()}"
    
    def __repr__(self):
        """Giderin Python temsilini döndürür."""
        return f"Gider(id={self.id}, tutar={self.tutar}, tarih='{self.tarih}')"

"""
utils.py
========
Kişisel Finans Takip Sistemi - Yardımcı Fonksiyonlar

Bu modül, sistemin tüm bölümlerinde kullanılan yardımcı fonksiyonları içerir.

Fonksiyonlar:
    - yeni_id_olustur(liste): Yeni benzersiz ID oluşturur
    - tarih_kontrol(tarih): Tarih formatını doğrular
    - sayi_kontrol(deger): Sayı dönüşümünü kontrol eder
    - menu_goster(): Ana menüyü ekrana yazdırır

Öğrenci: Ömer Taha Aldı
Numara: 24903060
Bölüm: Yönetim Bilişim Sistemleri
Ders: BGY210 - Python Programlama-II
"""

from datetime import datetime


def yeni_id_olustur(liste):
    """
    Verilen listedeki en büyük ID'yi bulup bir artırarak yeni benzersiz ID üretir.
    
    Eğer liste boşsa, 1 ile başlar.
    
    Args:
        liste (list): İşlem nesnelerini içeren liste
    
    Returns:
        int: Yeni benzersiz ID
    
    Örnek:
        >>> yeni_id = yeni_id_olustur(gelirler)
        >>> print(yeni_id)
        5
    """
    if not liste:
        return 1
    
    # Listedeki tüm ID'leri al
    ids = [islem.id for islem in liste]
    
    # En büyük ID'yi bul ve bir artır
    return max(ids) + 1


def tarih_kontrol(tarih):
    """
    Girilen tarihin doğru formatta (YYYY-MM-DD) olup olmadığını kontrol eder.
    
    Args:
        tarih (str): Kontrol edilecek tarih
    
    Returns:
        bool: Geçerli formatta ise True, değilse False
    
    Örnek:
        >>> tarih_kontrol("2024-12-25")
        True
        >>> tarih_kontrol("25/12/2024")
        False
    """
    try:
        datetime.strptime(tarih, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def sayi_kontrol(deger):
    """
    Kullanıcıdan alınan değerin sayıya dönüştürülebilir olup olmadığını kontrol eder.
    
    Args:
        deger (str): Kontrol edilecek değer
    
    Returns:
        tuple: (başarı: bool, sayı: float veya None)
    
    Örnek:
        >>> basarili, sayi = sayi_kontrol("123.45")
        >>> print(basarili, sayi)
        True 123.45
    """
    try:
        sayi = float(deger)
        if sayi < 0:
            return False, None  # Negatif sayılara izin verme
        return True, sayi
    except ValueError:
        return False, None


def menu_goster():
    """
    Programın ana menüsünü kullanıcıya ekrana yazdırır.
    
    Menü seçenekleri:
        1. Gelir Ekle
        2. Gider Ekle
        3. Listele
        4. Analiz Yap
        5. Grafik Göster
        6. CSV Kaydet
        7. Çıkış
    
    Returns:
        None
    """
    print("\n" + "="*50)
    print("KİŞİSEL FİNANS VE HARCAMA TAKIP SİSTEMİ".center(50))
    print("="*50)
    print("\n📊 ANA MENÜ\n")
    print("1. 💰 Gelir Ekle")
    print("2. 💸 Gider Ekle")
    print("3. 📋 Tüm İşlemleri Listele")
    print("4. 📈 Analiz Yap")
    print("5. 📊 Grafik Göster")
    print("6. 💾 CSV Dosyasına Kaydet")
    print("7. 🚪 Çıkış")
    print("\n" + "-"*50)
    print("Seçiminizi yapınız (1-7): ", end="")


def baslik_yazdir(baslik):
    """
    Ekrana formatlanmış başlık yazdırır.
    
    Args:
        baslik (str): Yazdırılacak başlık metni
    
    Returns:
        None
    """
    print(f"\n{'='*50}")
    print(f"{baslik.center(50)}")
    print(f"{'='*50}\n")


def hata_mesaji(mesaj):
    """
    Ekrana hata mesajı yazdırır.
    
    Args:
        mesaj (str): Hata mesajı
    
    Returns:
        None
    """
    print(f"\n❌ HATA: {mesaj}")


def basarili_mesaji(mesaj):
    """
    Ekrana başarı mesajı yazdırır.
    
    Args:
        mesaj (str): Başarı mesajı
    
    Returns:
        None
    """
    print(f"\n✅ BAŞARILI: {mesaj}")


def uyari_mesaji(mesaj):
    """
    Ekrana uyarı mesajı yazdırır.
    
    Args:
        mesaj (str): Uyarı mesajı
    
    Returns:
        None
    """
    print(f"\n⚠️  UYARI: {mesaj}")

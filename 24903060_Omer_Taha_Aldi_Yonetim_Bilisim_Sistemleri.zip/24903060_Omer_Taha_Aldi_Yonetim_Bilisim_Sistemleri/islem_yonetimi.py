"""
islem_yonetimi.py
=================
Kişisel Finans Takip Sistemi - İşlem Yönetimi

Bu modül, gelir ve gider işlemlerinin eklenmesi, silinmesi ve listelenmesini
sağlayan fonksiyonları içerir.

Fonksiyonlar:
    - gelir_ekle(gelirler): Yeni gelir kaydı ekler
    - gider_ekle(giderler): Yeni gider kaydı ekler
    - islemleri_listele(gelirler, giderler): Tüm işlemleri listeler
    - islem_sil(gelirler, giderler, id): İşlem siler

Öğrenci: Ömer Taha Aldı
Numara: 24903060
Bölüm: Yönetim Bilişim Sistemleri
Ders: BGY210 - Python Programlama-II
"""

from finans_modeli import Gelir, Gider
from utils import (
    yeni_id_olustur, tarih_kontrol, sayi_kontrol,
    hata_mesaji, basarili_mesaji, uyari_mesaji
)


def gelir_ekle(gelirler):
    """
    Kullanıcıdan alınan bilgileri doğrulayarak yeni bir gelir kaydı oluşturur
    ve listeye ekler.
    
    Gelir kategorileri: Maaş, Bonus, Yatırım, Diğer
    
    Args:
        gelirler (list): Gelir nesnelerini içeren liste
    
    Returns:
        None
    
    Örnek:
        >>> gelir_ekle(gelirler)
        Gelir Kategorisini seçiniz (1=Maaş, 2=Bonus, 3=Yatırım, 4=Diğer): 1
        Tutar (TL): 5000
        Tarih (YYYY-MM-DD): 2024-12-01
        Açıklama: Aylık maaş
        ✅ BAŞARILI: Gelir başarıyla eklendi!
    """
    try:
        # Kategori seçimi
        print("\n📊 GELİR KATEGORİSİ SEÇİNİZ")
        print("1. Maaş")
        print("2. Bonus")
        print("3. Yatırım")
        print("4. Diğer")
        
        kategori_secim = input("Seçiminiz (1-4): ").strip()
        kategoriler = {
            "1": "Maaş",
            "2": "Bonus",
            "3": "Yatırım",
            "4": "Diğer"
        }
        
        if kategori_secim not in kategoriler:
            hata_mesaji("Geçersiz kategori seçimi!")
            return
        
        kategori = kategoriler[kategori_secim]
        
        # Tutar girişi
        tutar_str = input("Tutar (TL): ").strip()
        basarili, tutar = sayi_kontrol(tutar_str)
        if not basarili or tutar == 0:
            hata_mesaji("Geçersiz tutar! Pozitif bir sayı giriniz.")
            return
        
        # Tarih girişi
        tarih = input("Tarih (YYYY-MM-DD): ").strip()
        if not tarih_kontrol(tarih):
            hata_mesaji("Geçersiz tarih formatı! YYYY-MM-DD kullanınız.")
            return
        
        # Açıklama girişi
        aciklama = input("Açıklama (opsiyonel): ").strip()
        
        # Yeni gelir oluştur ve listeye ekle
        yeni_id = yeni_id_olustur(gelirler)
        yeni_gelir = Gelir(yeni_id, tutar, tarih, kategori, aciklama)
        gelirler.append(yeni_gelir)
        
        basarili_mesaji(f"Gelir başarıyla eklendi! (ID: {yeni_id})")
    
    except Exception as e:
        hata_mesaji(f"Gelir eklenirken hata oluştu: {str(e)}")


def gider_ekle(giderler):
    """
    Kullanıcıdan alınan bilgileri doğrulayarak yeni bir gider kaydı oluşturur
    ve listeye ekler.
    
    Gider kategorileri: Yiyecek, Ulaşım, Eğlence, Sağlık, Diğer
    
    Args:
        giderler (list): Gider nesnelerini içeren liste
    
    Returns:
        None
    
    Örnek:
        >>> gider_ekle(giderler)
        Gider Kategorisini seçiniz (1=Yiyecek, 2=Ulaşım, ...): 1
        Tutar (TL): 150
        Tarih (YYYY-MM-DD): 2024-12-15
        Açıklama: Market alışveriş
        ✅ BAŞARILI: Gider başarıyla eklendi!
    """
    try:
        # Kategori seçimi
        print("\n📊 GİDER KATEGORİSİ SEÇİNİZ")
        print("1. Yiyecek")
        print("2. Ulaşım")
        print("3. Eğlence")
        print("4. Sağlık")
        print("5. Diğer")
        
        kategori_secim = input("Seçiminiz (1-5): ").strip()
        kategoriler = {
            "1": "Yiyecek",
            "2": "Ulaşım",
            "3": "Eğlence",
            "4": "Sağlık",
            "5": "Diğer"
        }
        
        if kategori_secim not in kategoriler:
            hata_mesaji("Geçersiz kategori seçimi!")
            return
        
        kategori = kategoriler[kategori_secim]
        
        # Tutar girişi
        tutar_str = input("Tutar (TL): ").strip()
        basarili, tutar = sayi_kontrol(tutar_str)
        if not basarili or tutar == 0:
            hata_mesaji("Geçersiz tutar! Pozitif bir sayı giriniz.")
            return
        
        # Tarih girişi
        tarih = input("Tarih (YYYY-MM-DD): ").strip()
        if not tarih_kontrol(tarih):
            hata_mesaji("Geçersiz tarih formatı! YYYY-MM-DD kullanınız.")
            return
        
        # Açıklama girişi
        aciklama = input("Açıklama (opsiyonel): ").strip()
        
        # Yeni gider oluştur ve listeye ekle
        yeni_id = yeni_id_olustur(giderler)
        yeni_gider = Gider(yeni_id, tutar, tarih, kategori, aciklama)
        giderler.append(yeni_gider)
        
        basarili_mesaji(f"Gider başarıyla eklendi! (ID: {yeni_id})")
    
    except Exception as e:
        hata_mesaji(f"Gider eklenirken hata oluştu: {str(e)}")


def islemleri_listele(gelirler, giderler):
    """
    Tüm gelir ve gider kayıtlarını düzenli bir formatta ekrana yazdırır.
    
    Args:
        gelirler (list): Gelir nesnelerini içeren liste
        giderler (list): Gider nesnelerini içeren liste
    
    Returns:
        None
    
    Örnek:
        >>> islemleri_listele(gelirler, giderler)
        ==================================================
                        TÜM İŞLEMLER
        ==================================================
        
        📊 GELİRLER (2 kayıt):
        [GELİR] ID: 1 | Tutar: 5000.00 TL | ...
        ...
    """
    print("\n" + "="*60)
    print("TÜM İŞLEMLER".center(60))
    print("="*60)
    
    # Gelirler
    if gelirler:
        print(f"\n💰 GELİRLER ({len(gelirler)} kayıt):\n")
        for gelir in gelirler:
            print(f"  {gelir}")
    else:
        print("\n💰 GELİRLER: Henüz gelir kaydı bulunmamaktadır.")
    
    # Giderler
    if giderler:
        print(f"\n💸 GİDERLER ({len(giderler)} kayıt):\n")
        for gider in giderler:
            print(f"  {gider}")
    else:
        print("\n💸 GİDERLER: Henüz gider kaydı bulunmamaktadır.")
    
    # Özet
    toplam_gelir = sum(g.tutar for g in gelirler)
    toplam_gider = sum(g.tutar for g in giderler)
    bakiye = toplam_gelir - toplam_gider
    
    print("\n" + "-"*60)
    print(f"📊 ÖZET:")
    print(f"  Toplam Gelir:  {toplam_gelir:>10.2f} TL")
    print(f"  Toplam Gider:  {toplam_gider:>10.2f} TL")
    print(f"  Net Bakiye:    {bakiye:>10.2f} TL")
    print("="*60)


def islem_sil(gelirler, giderler, id):
    """
    Verilen ID'ye sahip işlemi bularak ilgili listeden siler.
    
    Args:
        gelirler (list): Gelir nesnelerini içeren liste
        giderler (list): Gider nesnelerini içeren liste
        id (int): Silinecek işlemin ID'si
    
    Returns:
        bool: İşlem silinmişse True, bulunamazsa False
    
    Örnek:
        >>> basarili = islem_sil(gelirler, giderler, 1)
        >>> if basarili:
        ...     print("İşlem silindi")
    """
    try:
        # Gelirler içinde ara
        for i, gelir in enumerate(gelirler):
            if gelir.id == id:
                silinen = gelirler.pop(i)
                basarili_mesaji(f"İşlem silindi: {silinen}")
                return True
        
        # Giderler içinde ara
        for i, gider in enumerate(giderler):
            if gider.id == id:
                silinen = giderler.pop(i)
                basarili_mesaji(f"İşlem silindi: {silinen}")
                return True
        
        # İşlem bulunamazsa
        hata_mesaji(f"ID {id} ile işlem bulunamadı!")
        return False
    
    except Exception as e:
        hata_mesaji(f"İşlem silinirken hata oluştu: {str(e)}")
        return False

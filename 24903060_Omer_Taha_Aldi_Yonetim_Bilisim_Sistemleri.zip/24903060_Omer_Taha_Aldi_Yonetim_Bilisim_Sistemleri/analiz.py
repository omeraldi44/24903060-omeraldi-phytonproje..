"""
analiz.py
=========
Kişisel Finans Takip Sistemi - Veri Analizi

Bu modül, Pandas ve NumPy kullanarak finansal verilerin analiz edilmesini
sağlayan fonksiyonları içerir.

Fonksiyonlar:
    - verileri_dataframe_yap(gelirler, giderler): DataFrame oluşturur
    - toplam_gelir_gider(df): Toplam gelir/gider hesaplar
    - aylik_analiz(df): Aylık analiz yapar
    - numpy_istatistik(df): NumPy ile istatistik hesaplar

Öğrenci: Ömer Taha Aldı
Numara: 24903060
Bölüm: Yönetim Bilişim Sistemleri
Ders: BGY210 - Python Programlama-II
"""

import pandas as pd
import numpy as np
from utils import hata_mesaji, basarili_mesaji


def verileri_dataframe_yap(gelirler, giderler):
    """
    Gelir ve gider listelerini birleştirerek pandas DataFrame yapısına dönüştürür.
    
    DataFrame sütunları: tip, id, tutar, tarih, kategori, aciklama
    
    Args:
        gelirler (list): Gelir nesnelerini içeren liste
        giderler (list): Gider nesnelerini içeren liste
    
    Returns:
        pd.DataFrame: Birleştirilmiş veri çerçevesi veya boş DataFrame
    
    Örnek:
        >>> df = verileri_dataframe_yap(gelirler, giderler)
        >>> print(df.head())
    """
    try:
        # Gelir ve gider sözlüklerini oluştur
        gelir_dicts = []
        for gelir in gelirler:
            d = gelir.to_dict()
            d['tip'] = 'Gelir'
            gelir_dicts.append(d)
        
        gider_dicts = []
        for gider in giderler:
            d = gider.to_dict()
            d['tip'] = 'Gider'
            gider_dicts.append(d)
        
        # Tüm verileri birleştir
        tum_veriler = gelir_dicts + gider_dicts
        
        if not tum_veriler:
            return pd.DataFrame()
        
        # DataFrame oluştur
        df = pd.DataFrame(tum_veriler)
        
        # Tarih sütununu datetime formatına dönüştür
        df['tarih'] = pd.to_datetime(df['tarih'])
        
        # Tutar sütununu float'a dönüştür
        df['tutar'] = df['tutar'].astype(float)
        
        return df
    
    except Exception as e:
        hata_mesaji(f"DataFrame oluşturma hatası: {str(e)}")
        return pd.DataFrame()


def toplam_gelir_gider(df):
    """
    DataFrame üzerinden toplam gelir ve toplam gider değerlerini hesaplar.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
    
    Returns:
        dict: {'toplam_gelir': float, 'toplam_gider': float, 'bakiye': float}
    
    Örnek:
        >>> sonuc = toplam_gelir_gider(df)
        >>> print(f"Toplam Gelir: {sonuc['toplam_gelir']:.2f} TL")
        >>> print(f"Toplam Gider: {sonuc['toplam_gider']:.2f} TL")
        >>> print(f"Bakiye: {sonuc['bakiye']:.2f} TL")
    """
    try:
        if df.empty:
            return {
                'toplam_gelir': 0.0,
                'toplam_gider': 0.0,
                'bakiye': 0.0
            }
        
        # Gelir ve giderleri ayır
        gelirler = df[df['tip'] == 'Gelir']['tutar'].sum()
        giderler = df[df['tip'] == 'Gider']['tutar'].sum()
        
        # NaN değerleri 0 olarak işle
        gelirler = gelirler if not pd.isna(gelirler) else 0.0
        giderler = giderler if not pd.isna(giderler) else 0.0
        
        bakiye = gelirler - giderler
        
        return {
            'toplam_gelir': float(gelirler),
            'toplam_gider': float(giderler),
            'bakiye': float(bakiye)
        }
    
    except Exception as e:
        hata_mesaji(f"Toplam hesaplama hatası: {str(e)}")
        return {
            'toplam_gelir': 0.0,
            'toplam_gider': 0.0,
            'bakiye': 0.0
        }


def aylik_analiz(df):
    """
    Verileri tarihe göre gruplayarak aylık bazda özet analiz oluşturur.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
    
    Returns:
        pd.DataFrame: Aylık gelir, gider ve bakiye bilgilerini içeren DataFrame
    
    Örnek:
        >>> aylik_df = aylik_analiz(df)
        >>> print(aylik_df)
                    Gelir   Gider   Bakiye
        2024-12    5000.0  500.00  4500.00
    """
    try:
        if df.empty:
            return pd.DataFrame()
        
        # Tarih sütununu datetime'a dönüştür (eğer değilse)
        if not pd.api.types.is_datetime64_any_dtype(df['tarih']):
            df['tarih'] = pd.to_datetime(df['tarih'])
        
        # Yıl-Ay formatında grupla
        df_copy = df.copy()
        df_copy['yil_ay'] = df_copy['tarih'].dt.to_period('M')
        
        # Tip ve yıl-ay'a göre grupla
        aylik = df_copy.groupby(['yil_ay', 'tip'])['tutar'].sum().unstack(fill_value=0)
        
        # Gelir ve Gider sütunlarını yeniden adlandır
        if 'Gelir' not in aylik.columns:
            aylik['Gelir'] = 0.0
        if 'Gider' not in aylik.columns:
            aylik['Gider'] = 0.0
        
        # Bakiye hesapla
        aylik['Bakiye'] = aylik['Gelir'] - aylik['Gider']
        
        # Sütun sırasını düzenle
        aylik = aylik[['Gelir', 'Gider', 'Bakiye']]
        
        return aylik
    
    except Exception as e:
        hata_mesaji(f"Aylık analiz hatası: {str(e)}")
        return pd.DataFrame()


def numpy_istatistik(df):
    """
    NumPy kullanarak veri üzerinde ortalama, minimum, maksimum ve
    standart sapma hesaplar.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
    
    Returns:
        dict: İstatistik bilgilerini içeren sözlük
    
    Örnek:
        >>> istatistik = numpy_istatistik(df)
        >>> print(f"Ortalama İşlem: {istatistik['ortalama']:.2f} TL")
        >>> print(f"Minimum: {istatistik['minimum']:.2f} TL")
        >>> print(f"Maksimum: {istatistik['maksimum']:.2f} TL")
    """
    try:
        if df.empty:
            return {
                'ortalama': 0.0,
                'minimum': 0.0,
                'maksimum': 0.0,
                'standart_sapma': 0.0,
                'medyan': 0.0,
                'toplam_islem': 0
            }
        
        # NumPy dizisine dönüştür
        tutarlar = np.array(df['tutar'].values, dtype=float)
        
        # İstatistikleri hesapla
        istatistikler = {
            'ortalama': float(np.mean(tutarlar)),
            'minimum': float(np.min(tutarlar)),
            'maksimum': float(np.max(tutarlar)),
            'standart_sapma': float(np.std(tutarlar)),
            'medyan': float(np.median(tutarlar)),
            'toplam_islem': len(tutarlar)
        }
        
        return istatistikler
    
    except Exception as e:
        hata_mesaji(f"NumPy istatistik hatası: {str(e)}")
        return {
            'ortalama': 0.0,
            'minimum': 0.0,
            'maksimum': 0.0,
            'standart_sapma': 0.0,
            'medyan': 0.0,
            'toplam_islem': 0
        }


def kategori_analizi(df):
    """
    Kategoriye göre gelir ve giderleri analiz eder.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
    
    Returns:
        dict: Kategori bazında analiz sonuçları
    
    Örnek:
        >>> kategori = kategori_analizi(df)
        >>> print(kategori)
    """
    try:
        if df.empty:
            return {}
        
        # Kategori ve tip'e göre grupla
        kategori_analiz = df.groupby(['kategori', 'tip'])['tutar'].sum().unstack(fill_value=0)
        
        return kategori_analiz.to_dict()
    
    except Exception as e:
        hata_mesaji(f"Kategori analizi hatası: {str(e)}")
        return {}

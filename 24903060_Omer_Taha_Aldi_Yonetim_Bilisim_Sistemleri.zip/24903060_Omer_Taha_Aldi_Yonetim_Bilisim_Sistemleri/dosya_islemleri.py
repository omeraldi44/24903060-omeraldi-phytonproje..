"""
dosya_islemleri.py
==================
Kişisel Finans Takip Sistemi - Dosya İşlemleri

Bu modül, gelir ve gider verilerinin CSV dosyasına kaydedilmesi ve
okunmasını sağlayan fonksiyonları içerir.

Fonksiyonlar:
    - csv_kaydet(dosya_adi, gelirler, giderler): Verileri CSV'ye kaydeder
    - csv_oku(dosya_adi): CSV dosyasından verileri okur

Öğrenci: Ömer Taha Aldı
Numara: 24903060
Bölüm: Yönetim Bilişim Sistemleri
Ders: BGY210 - Python Programlama-II
"""

import csv
import os
from finans_modeli import Gelir, Gider
from utils import hata_mesaji, basarili_mesaji, uyari_mesaji


def csv_kaydet(dosya_adi, gelirler, giderler):
    """
    Tüm gelir ve gider verilerini belirtilen CSV dosyasına kaydeder.
    
    CSV formatı:
        tip,id,tutar,tarih,kategori,aciklama
        Gelir,1,5000.00,2024-12-01,Maaş,Aylık maaş
        Gider,1,150.00,2024-12-15,Yiyecek,Market alışveriş
    
    Args:
        dosya_adi (str): Kaydedilecek CSV dosyasının adı
        gelirler (list): Gelir nesnelerini içeren liste
        giderler (list): Gider nesnelerini içeren liste
    
    Returns:
        bool: Başarılıysa True, hata oluşursa False
    
    Örnek:
        >>> basarili = csv_kaydet("data/finanslar.csv", gelirler, giderler)
        >>> if basarili:
        ...     print("Veriler kaydedildi")
    """
    try:
        # Dosya dizinini oluştur (eğer yoksa)
        dosya_dizini = os.path.dirname(dosya_adi)
        if dosya_dizini and not os.path.exists(dosya_dizini):
            os.makedirs(dosya_dizini)
        
        # CSV dosyasını aç ve yaz
        with open(dosya_adi, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['tip', 'id', 'tutar', 'tarih', 'kategori', 'aciklama']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            # Başlık satırını yaz
            writer.writeheader()
            
            # Gelir verilerini yaz
            for gelir in gelirler:
                writer.writerow({
                    'tip': 'Gelir',
                    'id': gelir.id,
                    'tutar': f"{gelir.tutar:.2f}",
                    'tarih': gelir.tarih,
                    'kategori': gelir.kategori,
                    'aciklama': gelir.aciklama
                })
            
            # Gider verilerini yaz
            for gider in giderler:
                writer.writerow({
                    'tip': 'Gider',
                    'id': gider.id,
                    'tutar': f"{gider.tutar:.2f}",
                    'tarih': gider.tarih,
                    'kategori': gider.kategori,
                    'aciklama': gider.aciklama
                })
        
        toplam_islem = len(gelirler) + len(giderler)
        basarili_mesaji(f"Veriler '{dosya_adi}' dosyasına kaydedildi! "
                       f"({toplam_islem} işlem)")
        return True
    
    except IOError as e:
        hata_mesaji(f"Dosya yazma hatası: {str(e)}")
        return False
    except Exception as e:
        hata_mesaji(f"CSV kayıt sırasında hata oluştu: {str(e)}")
        return False


def csv_oku(dosya_adi):
    """
    CSV dosyasındaki verileri okuyarak gelir ve gider listelerini oluşturur.
    
    CSV formatı beklentisi:
        tip,id,tutar,tarih,kategori,aciklama
    
    Args:
        dosya_adi (str): Okunacak CSV dosyasının adı
    
    Returns:
        tuple: (gelirler: list, giderler: list) veya ([], []) hata durumunda
    
    Örnek:
        >>> gelirler, giderler = csv_oku("data/finanslar.csv")
        >>> print(f"Okunan gelir sayısı: {len(gelirler)}")
    """
    gelirler = []
    giderler = []
    
    try:
        # Dosya var mı kontrol et
        if not os.path.exists(dosya_adi):
            uyari_mesaji(f"Dosya bulunamadı: {dosya_adi}")
            return gelirler, giderler
        
        # CSV dosyasını oku
        with open(dosya_adi, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            
            # Başlık satırı kontrol et
            if reader.fieldnames != ['tip', 'id', 'tutar', 'tarih', 'kategori', 'aciklama']:
                hata_mesaji("CSV dosyası geçersiz formatta!")
                return gelirler, giderler
            
            # Verileri oku
            for row in reader:
                try:
                    # Veriler dönüştür
                    id_val = int(row['id'])
                    tutar_val = float(row['tutar'])
                    tarih_val = row['tarih']
                    kategori_val = row['kategori']
                    aciklama_val = row['aciklama']
                    tip_val = row['tip']
                    
                    # İşlem oluştur
                    if tip_val == 'Gelir':
                        islem = Gelir(id_val, tutar_val, tarih_val, kategori_val, aciklama_val)
                        gelirler.append(islem)
                    elif tip_val == 'Gider':
                        islem = Gider(id_val, tutar_val, tarih_val, kategori_val, aciklama_val)
                        giderler.append(islem)
                
                except (ValueError, KeyError) as e:
                    uyari_mesaji(f"Satır okunurken hata: {str(e)}")
                    continue
        
        toplam_islem = len(gelirler) + len(giderler)
        basarili_mesaji(f"'{dosya_adi}' dosyasından {toplam_islem} işlem okundu! "
                       f"({len(gelirler)} gelir, {len(giderler)} gider)")
        return gelirler, giderler
    
    except IOError as e:
        hata_mesaji(f"Dosya okuma hatası: {str(e)}")
        return gelirler, giderler
    except Exception as e:
        hata_mesaji(f"CSV okuma sırasında hata oluştu: {str(e)}")
        return gelirler, giderler

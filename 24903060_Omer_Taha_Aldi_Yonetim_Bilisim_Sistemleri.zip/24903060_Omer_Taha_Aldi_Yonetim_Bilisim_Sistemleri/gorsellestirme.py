"""
gorsellestirme.py
=================
Kişisel Finans Takip Sistemi - Veri Görselleştirme

Bu modül, Matplotlib ve Seaborn kullanarak finansal verilerin grafik
olarak görselleştirilmesini sağlayan fonksiyonları içerir.

Fonksiyonlar:
    - aylik_grafik(df): Aylık gelir/gider çizgi grafiği
    - gelir_gider_bar(df): Gelir/gider sütun grafiği
    - pasta_grafik(df): Gelir/gider oranı pasta grafiği
    - kategori_grafik(df): Kategori bazında görselleştirme

Öğrenci: Ömer Taha Aldı
Numara: 24903060
Bölüm: Yönetim Bilişim Sistemleri
Ders: BGY210 - Python Programlama-II
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from analiz import aylik_analiz, toplam_gelir_gider
from utils import hata_mesaji, basarili_mesaji

# Matplotlib ayarları
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 10
sns.set_style("whitegrid")


def aylik_grafik(df, dosya_adi=None):
    """
    Aylık gelir ve giderleri karşılaştıran çizgi grafiği oluşturur.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
        dosya_adi (str): Grafiği kaydetmek için dosya adı (opsiyonel)
    
    Returns:
        None
    
    Örnek:
        >>> aylik_grafik(df, "outputs/aylik_grafik.png")
    """
    try:
        if df.empty:
            hata_mesaji("Grafik oluşturmak için veri bulunmamaktadır!")
            return
        
        # Aylık analiz yap
        aylik_df = aylik_analiz(df)
        
        if aylik_df.empty:
            hata_mesaji("Aylık analiz yapılamadı!")
            return
        
        # Grafik oluştur
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # Çizgileri çiz
        ax.plot(aylik_df.index.astype(str), aylik_df['Gelir'], 
                marker='o', linewidth=2, label='Gelir', color='#2ecc71')
        ax.plot(aylik_df.index.astype(str), aylik_df['Gider'], 
                marker='s', linewidth=2, label='Gider', color='#e74c3c')
        ax.plot(aylik_df.index.astype(str), aylik_df['Bakiye'], 
                marker='^', linewidth=2, label='Bakiye', color='#3498db')
        
        # Başlık ve etiketler
        ax.set_title('Aylık Gelir, Gider ve Bakiye Analizi', fontsize=14, fontweight='bold')
        ax.set_xlabel('Ay', fontsize=12)
        ax.set_ylabel('Tutar (TL)', fontsize=12)
        ax.legend(loc='best', fontsize=10)
        ax.grid(True, alpha=0.3)
        
        # Ekseni döndür
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        # Grafiği göster veya kaydet
        if dosya_adi:
            plt.savefig(dosya_adi, dpi=300, bbox_inches='tight')
            basarili_mesaji(f"Aylık grafik '{dosya_adi}' olarak kaydedildi!")
        else:
            plt.show()
        
        plt.close()
    
    except Exception as e:
        hata_mesaji(f"Aylık grafik oluşturma hatası: {str(e)}")


def gelir_gider_bar(df, dosya_adi=None):
    """
    Toplam gelir ve gider değerlerini karşılaştıran sütun grafiği oluşturur.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
        dosya_adi (str): Grafiği kaydetmek için dosya adı (opsiyonel)
    
    Returns:
        None
    
    Örnek:
        >>> gelir_gider_bar(df, "outputs/gelir_gider_bar.png")
    """
    try:
        if df.empty:
            hata_mesaji("Grafik oluşturmak için veri bulunmamaktadır!")
            return
        
        # Toplam gelir ve gider hesapla
        sonuc = toplam_gelir_gider(df)
        
        # Grafik oluştur
        fig, ax = plt.subplots(figsize=(10, 6))
        
        kategoriler = ['Gelir', 'Gider']
        tutarlar = [sonuc['toplam_gelir'], sonuc['toplam_gider']]
        renkler = ['#2ecc71', '#e74c3c']
        
        # Sütun grafiği çiz
        bars = ax.bar(kategoriler, tutarlar, color=renkler, alpha=0.8, edgecolor='black', linewidth=1.5)
        
        # Sütunlara değer ekle
        for bar, tutar in zip(bars, tutarlar):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{tutar:.2f} TL',
                   ha='center', va='bottom', fontsize=11, fontweight='bold')
        
        # Başlık ve etiketler
        ax.set_title('Toplam Gelir ve Gider Karşılaştırması', fontsize=14, fontweight='bold')
        ax.set_ylabel('Tutar (TL)', fontsize=12)
        ax.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        # Grafiği göster veya kaydet
        if dosya_adi:
            plt.savefig(dosya_adi, dpi=300, bbox_inches='tight')
            basarili_mesaji(f"Gelir-Gider grafiği '{dosya_adi}' olarak kaydedildi!")
        else:
            plt.show()
        
        plt.close()
    
    except Exception as e:
        hata_mesaji(f"Gelir-Gider grafiği oluşturma hatası: {str(e)}")


def pasta_grafik(df, dosya_adi=None):
    """
    Gelir ve gider oranlarını gösteren pasta grafiği oluşturur.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
        dosya_adi (str): Grafiği kaydetmek için dosya adı (opsiyonel)
    
    Returns:
        None
    
    Örnek:
        >>> pasta_grafik(df, "outputs/pasta_grafik.png")
    """
    try:
        if df.empty:
            hata_mesaji("Grafik oluşturmak için veri bulunmamaktadır!")
            return
        
        # Toplam gelir ve gider hesapla
        sonuc = toplam_gelir_gider(df)
        
        # Grafik oluştur
        fig, ax = plt.subplots(figsize=(10, 8))
        
        labels = ['Gelir', 'Gider']
        sizes = [sonuc['toplam_gelir'], sonuc['toplam_gider']]
        colors = ['#2ecc71', '#e74c3c']
        explode = (0.05, 0.05)
        
        # Pasta grafiği çiz
        wedges, texts, autotexts = ax.pie(sizes, explode=explode, labels=labels, colors=colors,
                                           autopct='%1.1f%%', shadow=True, startangle=90,
                                           textprops={'fontsize': 11, 'fontweight': 'bold'})
        
        # Başlık
        ax.set_title('Gelir ve Gider Oranları', fontsize=14, fontweight='bold')
        
        # Efsane ekle
        legend_labels = [f'{labels[i]}: {sizes[i]:.2f} TL' for i in range(len(labels))]
        ax.legend(legend_labels, loc='upper left', fontsize=10)
        
        plt.tight_layout()
        
        # Grafiği göster veya kaydet
        if dosya_adi:
            plt.savefig(dosya_adi, dpi=300, bbox_inches='tight')
            basarili_mesaji(f"Pasta grafiği '{dosya_adi}' olarak kaydedildi!")
        else:
            plt.show()
        
        plt.close()
    
    except Exception as e:
        hata_mesaji(f"Pasta grafiği oluşturma hatası: {str(e)}")


def kategori_grafik(df, dosya_adi=None):
    """
    Kategoriye göre gelir ve giderleri gösteren yatay sütun grafiği oluşturur.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
        dosya_adi (str): Grafiği kaydetmek için dosya adı (opsiyonel)
    
    Returns:
        None
    
    Örnek:
        >>> kategori_grafik(df, "outputs/kategori_grafik.png")
    """
    try:
        if df.empty:
            hata_mesaji("Grafik oluşturmak için veri bulunmamaktadır!")
            return
        
        # Kategoriye göre grupla
        kategori_grup = df.groupby(['kategori', 'tip'])['tutar'].sum().unstack(fill_value=0)
        
        if kategori_grup.empty:
            hata_mesaji("Kategori verisi bulunmamaktadır!")
            return
        
        # Grafik oluştur
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # Yatay sütun grafiği çiz
        kategori_grup.plot(kind='barh', ax=ax, color=['#2ecc71', '#e74c3c'], alpha=0.8, edgecolor='black')
        
        # Başlık ve etiketler
        ax.set_title('Kategoriye Göre Gelir ve Gider Analizi', fontsize=14, fontweight='bold')
        ax.set_xlabel('Tutar (TL)', fontsize=12)
        ax.set_ylabel('Kategori', fontsize=12)
        ax.legend(['Gelir', 'Gider'], loc='best', fontsize=10)
        ax.grid(True, alpha=0.3, axis='x')
        
        plt.tight_layout()
        
        # Grafiği göster veya kaydet
        if dosya_adi:
            plt.savefig(dosya_adi, dpi=300, bbox_inches='tight')
            basarili_mesaji(f"Kategori grafiği '{dosya_adi}' olarak kaydedildi!")
        else:
            plt.show()
        
        plt.close()
    
    except Exception as e:
        hata_mesaji(f"Kategori grafiği oluşturma hatası: {str(e)}")


def tum_grafikleri_kaydet(df, output_dir='outputs'):
    """
    Tüm grafikleri belirtilen dizine kaydeder.
    
    Args:
        df (pd.DataFrame): Finansal verileri içeren DataFrame
        output_dir (str): Çıktı dizini
    
    Returns:
        None
    """
    import os
    
    # Dizin oluştur (eğer yoksa)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Tüm grafikleri kaydet
    aylik_grafik(df, f"{output_dir}/aylik_grafik.png")
    gelir_gider_bar(df, f"{output_dir}/gelir_gider_bar.png")
    pasta_grafik(df, f"{output_dir}/pasta_grafik.png")
    kategori_grafik(df, f"{output_dir}/kategori_grafik.png")
    
    basarili_mesaji(f"Tüm grafikler '{output_dir}' dizinine kaydedildi!")
